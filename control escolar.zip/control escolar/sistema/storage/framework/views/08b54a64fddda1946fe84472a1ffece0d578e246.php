<?php $__env->startSection('content'); ?>
<div class="content" style="text-align:center;">
    <h2>Sistema de control escolar</h2>
    <h2><i class="fas fa-school"></i></h2>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Armando\aplicaciones\alumnos\resources\views/welcome.blade.php */ ?>