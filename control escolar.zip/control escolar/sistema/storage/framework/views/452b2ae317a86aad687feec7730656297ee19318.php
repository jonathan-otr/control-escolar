<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Selecciona un alumno para editarlo o borrarlo de la base de datos.</div>

                <div class="card-body">
                  <?php if(session('alert')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('alert')); ?>

                      </div>
                  <?php endif; ?>
                  <?php if(session('error')): ?>
                      <div class="alert alert-danger">
                          <?php echo e(session('alert')); ?>

                      </div>
                  <?php endif; ?>
                  <div class="form-group row">
                      <label for="email" class="col-md-6 col-form-label text-md-left">Nombre</label>
                      <label for="email" class="col-md-4 col-form-label text-md-left">Se imparte en ingles?</label>
                      <label for="email" class="col-md-2 col-form-label text-md-left">Opciones</label>
                  </div>
                  <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-group row">
                      <label for="email" class="col-md-6 col-form-label text-md-left"><?php echo e($c->curso_nombre); ?></label>
                      <?php if ($c->curso_ingles == '1'): ?>
                        <label for="email" class="col-md-4 col-form-label text-md-left">Sí</label>
                        <?php else: ?>
                          <label for="email" class="col-md-4 col-form-label text-md-left">No</label>
                      <?php endif; ?>
                      <a href="<?php echo e(Route('editar_curso',Crypt::encrypt($c->id_curso))); ?>" class="btn btn-primary col-md-1" style="max-height: 40px;"><i class="fas fa-edit"></i></a>
                      <a href="<?php echo e(Route('eliminar_curso',Crypt::encrypt($c->id_curso))); ?>" onclick="return confirm('Seguro que deseas eliminarlo?');" class="btn btn-danger col-md-1" style="max-height: 40px;"><i class="fas fa-trash-alt"></i></a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Armando\aplicaciones\alumnos\resources\views/editar_cursos.blade.php */ ?>