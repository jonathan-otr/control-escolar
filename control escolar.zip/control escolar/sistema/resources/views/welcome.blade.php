@extends('layouts.app')

@section('content')
<div class="content" style="text-align:center;">
    <h2>Sistema de control escolar</h2>
    <h2><i class="fas fa-school"></i></h2>
</div>
@endsection
